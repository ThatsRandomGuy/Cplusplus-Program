#include <iostream>
#include <fstream>
#include <unordered_map>

using namespace std;

//Creating public and private variables
class cornerGrocer {
    private:
        int placeholder;
    public:
        string currWord;
        int wordFreq;
        string userWord;
        int optionNum;

};

//Creating main
int main() {
    fstream inputFile;
    inputFile.open("CS210_Project_Three_Input_File.txt");

    if (!inputFile.is_open()) {
        cout << "Could not open the input file!" << endl;
        return 0;
    }

    //Creating backup data file
    ofstream backupData("frequency.dat");

    if (!backupData.is_open()) {
        cout << "Error opening output file!" << endl;
        return 0;
    }

    if (backupData.is_open()) {
        unordered_map<string, int> backupItemFrequency;

        string backupWord;
        while(inputFile >> backupWord) {
            backupItemFrequency[backupWord]++;
        }

        for (const auto& [backupItem, backupFrequency] : backupItemFrequency) {
            backupData << backupItem << " " << backupFrequency << endl;
        }
        backupData.close();
        inputFile.close();
    }

    inputFile.open("CS210_Project_Three_Input_File.txt");
    
    //Getting user option selection
    cout << "-----------------------------------------------" << endl;
    cout << "Enter the number of the option you would like." << endl;
    cout << "1: Item quantity lookup" << endl;
    cout << "2: Item quantity list" << endl;
    cout << "3: Item quantity histogram" << endl;
    cout << "4: Exit" << endl;
    cout << "-----------------------------------------------" << endl;

    cin >> cornerGrocer.optionNum;

    //Creating options
    if (cornerGrocer.optionNum == 1) {
        cout << "Enter a word (case sensitive): ";
        cin >> cornerGrocer.userWord;

        cout << endl;

        while (!inputFile.eof()) {
            inputFile >> cornerGrocer.currWord;
            if (!inputFile.fail()) {
                if (cornerGrocer.currWord == cornerGrocer.userWord) {
                    ++cornerGrocer.wordFreq;
                }
            }
        }
        cout << cornerGrocer.userWord << " appears " << cornerGrocer.wordFreq << " times" << endl;
        cout << endl;
        cout << endl;
        main();
    }
    else if (cornerGrocer.optionNum == 2) {
        unordered_map<string, int> itemFrequency;

        string word;
        while(inputFile >> word) {
            itemFrequency[word]++;
        }

        for (const auto& [item, frequency] : itemFrequency) {
            cout << item << " " << frequency << endl;
            
        }
        cout << endl;
        cout << endl;
        main();
    }
    else if (cornerGrocer.optionNum == 3) {
        unordered_map<string, int> itemFrequency;

        string word;
        while(inputFile >> word) {
            itemFrequency[word]++;
        }

        for (const auto& [item, frequency] : itemFrequency) {
            cout << item << " ";
            for (int i = 0; i < frequency; ++i) {
                cout << '*';
            }
            cout << endl;
        }
        cout << endl;
        cout << endl;
        main();
    }
    else if (cornerGrocer.optionNum == 4) {
        inputFile.close();
        return 0;
    }
    else {
        cout << "This is not a valid option!";
        main();
    }

}